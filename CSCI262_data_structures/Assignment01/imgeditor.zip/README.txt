/*
README

author: ADAM LONGORIA
date: 1/31/14

Image editing program for CSCI 262, Spring 2014, Assignment 1.

This program will read a ppm picture file and apply filter to the image
and output a ppm picture file with the applied filters.
*/

1. Eric Sheeder, Roy Stillwell

2. The hardest part of this assignment was dynamically allocating 2D arrays,
   to make this work i just followed the class lecture slides. For the blur 
   i couldn't quite get all the border conditions to work so instead i just
   ignored the border of pixels since they are really small any way. In
   doing this there is no noticable difference. 

3. I didn't dislike anything really, i would just perfer we cover pointers
   and arrays more in class; especially if they are going to be on the exam.
   Also, it would be more helpful to learn the material if the labs and the
   assignments were more specific on how to approach the problem. Just like
   261 assignments were setup; (X points for completing TASK_A with while 
   loops, X points for completing TASK_B with pointers, ect......) I feel 
   this would better prepare for the exams and overall C++ proficiency.

4. Time spent ~ 12 hours