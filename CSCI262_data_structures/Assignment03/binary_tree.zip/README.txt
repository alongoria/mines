/*
README

author: ADAM LONGORIA
date:   04/01/14

Image editing program for CSCI 262, Spring 2014, Assignment 2.

20 Questions
*/

1. Eric Sheeder, Roy Stillwell

2. Not many challenges, mostly just small errors made. (ie. syntax, etc)

3. good practice with binary trees and recursion

4. Time spent ~ 4 hours
