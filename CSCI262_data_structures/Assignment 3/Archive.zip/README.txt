20 Questions
Author: Roy Stillwell , 4.2.14
Colorado School of Mines, EECS 262 
Assignment 3

The 20 questions game (animal version) is a game that will have the computer ask you questions to guess an animal.  If it does not guess the animal, it will ask ti have you help teach it.  You can save its knowledge base to a text file (animal.txt) and it can read in from this file.
 
Usage:
Type ‘1’ to play
Type ‘2’ to save
Type ‘3’ to quit.  

Issues: 
I’m sure there are bugs, but for the use cases I could think of, it works.  Also if there is no memory file, it will generate a generic one to get started.

For Assignment2:	
1.  Worked with Adam Longoria and Eric Sheeder.
2.  Recursive functions were the name of the game, which was intimidating at first (Recursive functions have always been a little sticky for me). It took some time to get used to how to work with them on the binary tree.  But after multiple recursion functions, I feel very confident w/ them now.  Cool assignment!

3. In a very simple way, we were kind of writing an AI.  Which is cool!

4.Probably 5 hours. 
