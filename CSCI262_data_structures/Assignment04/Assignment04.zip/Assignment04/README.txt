/*
README

author: ADAM LONGORIA
date:   05/02/14

Markov chains program for CSCI 262, Spring 2014, Assignment 3.

Marvok
*/

1. Eric Sheeder

2. Not many challenges, mostly just small errors made. (ie. syntax, etc)

3. good practice with maps, cool example of real world application

4. Time spent ~ 7 hours

