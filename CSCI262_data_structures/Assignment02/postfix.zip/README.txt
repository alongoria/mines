/*
README

author: ADAM LONGORIA
date:   03/18/14

Image editing program for CSCI 262, Spring 2014, Assignment 1.

Reverse Polish notation (RPN) calculator
*/

1. Eric Sheeder, Roy Stillwell

2. Not many challenges, mostly just small errors made. (ie. syntax, etc)

3. good practice with stacks

4. Time spent ~ 4 hours

5. 
	a) I added a funtion that would print the contents of the stack. This was
	   helpful for debugging
	b) accounted for the situation when the user inputs a '\' instead of a '/'.
	   '\' is an escape character
	c) added a few more calculator funtions. mod, floor, ceil, round, avg,
	   trunc, abs, hypo
	d) wanted to add a "list operations" funtion for the ui, but that would 
	   have required modifying the calculator_main.cpp file