using namespace std;

extern const string NAME;
extern const int LEFT_MARGIN;
extern const int BANNER_COLOR_RED;
extern const int BANNER_COLOR_GREEN;
extern const int BANNER_COLOR_BLUE;