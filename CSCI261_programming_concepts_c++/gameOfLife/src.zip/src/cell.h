#pragma once

class Cell {
	bool alive;	
public:
	Cell();
	void setCellState(bool b);
	bool getCellState();
};