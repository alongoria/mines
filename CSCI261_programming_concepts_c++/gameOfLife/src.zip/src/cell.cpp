#include "cell.h"

Cell::Cell() {
	alive = false;
}

void Cell::setCellState(bool b) {
	alive = b;
}

bool Cell::getCellState() {
	return alive;
}